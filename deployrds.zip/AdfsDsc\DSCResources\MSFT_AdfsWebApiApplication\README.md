# Description

The AdfsWebApiApplication DSC resource manages Web API Applications within Active Directory Federation
Services. Web Api Applications are a construct that represents a web API secured by ADFS.

## Requirements

* Target machine must be running ADFS on Windows Server 2016 or above to use this resource.

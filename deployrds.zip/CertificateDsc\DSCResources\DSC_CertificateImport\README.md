# Description

The resource is used to import a certificate into a Windows certificate
store.

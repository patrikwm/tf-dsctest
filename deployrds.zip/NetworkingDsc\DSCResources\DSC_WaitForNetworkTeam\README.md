# Description

The resource is used to wait for a network team to achieve the 'Up' status.
